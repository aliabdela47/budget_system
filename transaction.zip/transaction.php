<?php
session_start();
include 'includes/db.php';
include 'includes/functions.php';
if (!isset($_SESSION['user_id'])) {
    header('Location: index.php');
    exit;
}

$owners = $pdo->query("SELECT * FROM budget_owners")->fetchAll();
$codes = $pdo->query("SELECT * FROM budget_codes")->fetchAll();
$transactions = $pdo->query("SELECT t.*, o.code AS owner_code, c.code AS budget_code 
                             FROM transactions t 
                             JOIN budget_owners o ON t.owner_id = o.id 
                             JOIN budget_codes c ON t.code_id = c.id")->fetchAll();

$trans = null;
if (isset($_GET['action']) && $_GET['action'] == 'edit' && isset($_GET['id'])) {
    $stmt = $pdo->prepare("SELECT * FROM transactions WHERE id = ?");
    $stmt->execute([$_GET['id']]);
    $trans = $stmt->fetch();
}

$et_info = getEtMonthAndQuarter(date('Y-m-d'));

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $owner_id = $_POST['owner_id'];
    $code_id = $_POST['code_id'];
    $amount = (float)($_POST['amount'] ?? 0); // Default to 0 if blank
    $et_month = $_POST['et_month'];
    $quarterMap = [
        'ሐምሌ' => 1, 'ነሐሴ' => 1, 'መስከረም' => 1,
        'ጥቅምት' => 2, 'ህዳር' => 2, 'ታኅሳስ' => 2,
        'ጥር' => 3, 'የካቲቷ' => 3, 'መጋቢቷ' => 3,
        'ሚያዝያ' => 4, 'ግንቦቷ' => 4, 'ሰኔ' => 4,
    ];
    $quarter = $quarterMap[$et_month] ?? 0;
    $year = date('Y') - 8; // Ethiopian year adjustment

    // Fetch monthly budget
    $stmt = $pdo->prepare("SELECT * FROM budgets WHERE owner_id = ? AND code_id = ? AND year = ? AND month = ?");
    $stmt->execute([$owner_id, $code_id, $year, $et_month]);
    $budget = $stmt->fetch();

    // Fetch yearly budget
    $stmt = $pdo->prepare("SELECT * FROM budgets WHERE owner_id = ? AND code_id = ? AND year = ? AND monthly_amount = 0");
    $stmt->execute([$owner_id, $code_id, $year]);
    $budget_yearly = $stmt->fetch();

    if ($budget_yearly || $budget) {
        $yearly_amount = $budget_yearly ? $budget_yearly['yearly_amount'] : 0;
        $monthly_amount = $budget ? $budget['monthly_amount'] : 0;

        // Calculate total spent from transactions
        $stmt = $pdo->prepare("SELECT SUM(amount) FROM transactions WHERE owner_id = ? AND code_id = ? AND YEAR(date) = ?");
        $stmt->execute([$owner_id, $code_id, date('Y')]);
        $trans_year = $stmt->fetchColumn() ?: 0;
        $calculated_remaining_year = $yearly_amount - $trans_year;

        $stmt = $pdo->prepare("SELECT SUM(amount) FROM transactions WHERE owner_id = ? AND code_id = ? AND et_month = ? AND YEAR(date) = ?");
        $stmt->execute([$owner_id, $code_id, $et_month, date('Y')]);
        $trans_month = $stmt->fetchColumn() ?: 0;
        $calculated_remaining_month = $monthly_amount - $trans_month;

        $stmt = $pdo->prepare("SELECT SUM(monthly_amount) FROM budgets WHERE owner_id = ? AND code_id = ? AND year = ? AND quarter = ?");
        $stmt->execute([$owner_id, $code_id, $year, $quarter]);
        $quarterly_alloc = $stmt->fetchColumn() ?: 0;

        $stmt = $pdo->prepare("SELECT SUM(amount) FROM transactions WHERE owner_id = ? AND code_id = ? AND quarter = ? AND YEAR(date) = ?");
        $stmt->execute([$owner_id, $code_id, $quarter, date('Y')]);
        $trans_quarter = $stmt->fetchColumn() ?: 0;
        $calculated_remaining_quarter = $quarterly_alloc - $trans_quarter;

        if (!$budget) {
            $calculated_remaining_month = $calculated_remaining_year;
        }

        if ($quarterly_alloc == 0) {
            $calculated_remaining_quarter = $calculated_remaining_year;
        }

        // Enhanced validation
        if ($amount < 0) {
            $message = 'Amount cannot be negative';
        } elseif ($amount > 0 && !$budget_yearly && !$budget) {
            $message = 'No budget allocated for this combination';
        } elseif ($amount > 0 && min($calculated_remaining_month, $calculated_remaining_quarter, $calculated_remaining_year) < $amount) {
            $message = 'Transaction amount exceeds remaining budget (Monthly: ' . number_format($calculated_remaining_month, 2) . ', Quarterly: ' . number_format($calculated_remaining_quarter, 2) . ', Yearly: ' . number_format($calculated_remaining_year, 2) . ')';
        } else {
            $pdo->beginTransaction();
            try {
                // Update budgets table with new amounts (initial amounts reduced by consumption)
                if ($amount > 0 && $budget) {
                    $new_monthly_amount = $monthly_amount - $amount;
                    $stmt = $pdo->prepare("UPDATE budgets SET monthly_amount = ? WHERE id = ?");
                    $stmt->execute([$new_monthly_amount, $budget['id']]);
                }
                if ($amount > 0 && $budget_yearly) {
                    $new_yearly_amount = $yearly_amount - $amount;
                    $stmt = $pdo->prepare("UPDATE budgets SET yearly_amount = ? WHERE id = ?");
                    $stmt->execute([$new_yearly_amount, $budget_yearly['id']]);
                }

                // Insert or update transaction
                $new_remaining_monthly = $calculated_remaining_month - $amount;
                $new_remaining_quarterly = $calculated_remaining_quarter - $amount;
                $new_remaining_yearly = $calculated_remaining_year - $amount;

                if (isset($_POST['id']) && $_POST['action'] == 'update') {
                    $stmt = $pdo->prepare("UPDATE transactions SET owner_id = ?, code_id = ?, employee_name = ?, ordered_by = ?, reason = ?, amount = ?, et_month = ?, quarter = ?, remaining_month = ?, remaining_quarter = ?, remaining_year = ? WHERE id = ?");
                    $stmt->execute([$owner_id, $code_id, $_POST['employee_name'], $_POST['ordered_by'], $_POST['reason'], $amount, $et_month, $quarter, $new_remaining_monthly, $new_remaining_quarterly, $new_remaining_yearly, $_POST['id']]);
                    $message = 'Transaction updated';
                } else {
                    $stmt = $pdo->prepare("INSERT INTO transactions (owner_id, code_id, employee_name, ordered_by, reason, created_by, amount, et_month, quarter, remaining_month, remaining_quarter, remaining_year, date) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())");
                    $stmt->execute([$owner_id, $code_id, $_POST['employee_name'], $_POST['ordered_by'], $_POST['reason'], $_SESSION['username'], $amount, $et_month, $quarter, $new_remaining_monthly, $new_remaining_quarterly, $new_remaining_yearly]);
                    $message = 'Transaction added';
                }

                $pdo->commit();
            } catch (Exception $e) {
                $pdo->rollBack();
                $message = 'Error: ' . $e->getMessage();
            }
        }
    } else {
        if ($amount > 0) {
            $message = 'No budget allocated for this combination';
        } else {
            // Allow zero amount transaction with no budget
            $pdo->beginTransaction();
            try {
                $stmt = $pdo->prepare("INSERT INTO transactions (owner_id, code_id, employee_name, ordered_by, reason, created_by, amount, et_month, quarter, remaining_month, remaining_quarter, remaining_year, date) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())");
                $stmt->execute([$owner_id, $code_id, $_POST['employee_name'], $_POST['ordered_by'], $_POST['reason'], $_SESSION['username'], $amount, $et_month, $quarter, 0, 0, 0]);
                $message = 'Transaction with zero amount added';
                $pdo->commit();
            } catch (Exception $e) {
                $pdo->rollBack();
                $message = 'Error: ' . $e->getMessage();
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="robots" content="noindex, nofollow">
    <title>Transaction - Budget System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap" rel="stylesheet">
    <link href="css/styles.css" rel="stylesheet">
    <script src="js/scripts.js"></script>
</head>
<body class="dashboard-body">
    <!-- Sidebar -->
    <div class="sidebar" id="sidebar">
        <div class="sidebar-header">
            <i class="fas fa-wallet fa-2x"></i>
            <h3>Budget System</h3>
        </div>
        <ul class="nav flex-column">
            <li class="nav-item">
                <a class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'dashboard.php' ? 'active' : ''; ?>" href="dashboard.php">
                    <i class="fas fa-tachometer-alt"></i> Dashboard
                </a>
            </li>
            <?php if ($_SESSION['role'] == 'admin'): ?>
                <li class="nav-item">
                    <a class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'budget_adding.php' ? 'active' : ''; ?>" href="budget_adding.php">
                        <i class="fas fa-plus-circle"></i> Budget Adding
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'settings_owners.php' ? 'active' : ''; ?>" href="settings_owners.php">
                        <i class="fas fa-building"></i> Settings Owners
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'settings_codes.php' ? 'active' : ''; ?>" href="settings_codes.php">
                        <i class="fas fa-code"></i> Settings Codes
                    </a>
                </li>
            <?php endif; ?>
            <li class="nav-item">
                <a class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'transaction.php' ? 'active' : ''; ?>" href="transaction.php">
                    <i class="fas fa-exchange-alt"></i> Transaction
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'fuel_management.php' ? 'active' : ''; ?>" href="fuel_management.php">
                    <i class="fas fa-gas-pump"></i> Fuel Management
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'users_management.php' ? 'active' : ''; ?>" href="users_management.php">
                    <i class="fas fa-users"></i> Users Management
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="logout.php">
                    <i class="fas fa-sign-out-alt"></i> Logout
                </a>
            </li>
        </ul>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <button class="btn btn-primary sidebar-toggle d-md-none" id="sidebarToggle">
            <i class="fas fa-bars"></i>
        </button>
        <div class="container-fluid">
            <div class="card dashboard-card mt-4">
                <div class="card-body">
                    <h2 class="card-title">Transaction Form</h2>
                    <?php if (isset($message)): ?>
                        <div class="alert alert-info alert-dismissible fade show" role="alert">
                            <?php echo htmlspecialchars($message); ?>
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>
                    <?php endif; ?>
                    <form method="post" class="needs-validation" novalidate>
                        <?php if ($trans): ?>
                            <input type="hidden" name="id" value="<?php echo $trans['id']; ?>">
                            <input type="hidden" name="action" value="update">
                        <?php endif; ?>
                        <div class="mb-3">
                            <label class="form-label">Budget Owners Code</label>
                            <select name="owner_id" class="form-control" onchange="loadAvailable()" required>
                                <?php foreach ($owners as $o): ?>
                                    <option value="<?php echo $o['id']; ?>" <?php echo ($trans && $trans['owner_id'] == $o['id']) ? 'selected' : ''; ?>>
                                        <?php echo htmlspecialchars($o['code'] . ' - ' . $o['name']); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                            <div class="invalid-feedback">Please select a budget owner.</div>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Budget Code</label>
                            <select name="code_id" class="form-control" onchange="loadAvailable()" required>
                                <?php
                                if (!empty($codes)) {
                                    foreach ($codes as $c) {
                                        echo '<option value="' . htmlspecialchars($c['id']) . '"';
                                        if ($trans && $trans['code_id'] == $c['id']) {
                                            echo ' selected';
                                        }
                                        echo '>' . htmlspecialchars($c['code'] . ' - ' . $c['name']) . '</option>';
                                    }
                                } else {
                                    echo '<option value="">No budget codes available</option>';
                                }
                                ?>
                            </select>
                            <div class="invalid-feedback">Please select a budget code.</div>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Ethiopian Month</label>
                            <select name="et_month" id="month" class="form-control" onchange="updateQuarter(); loadAvailable();" required>
                                <?php
                                if (isset($etMonths) && is_array($etMonths)) {
                                    foreach ($etMonths as $month) {
                                        echo '<option value="' . htmlspecialchars($month) . '"';
                                        if (($trans && $trans['et_month'] == $month) || (!$trans && $et_info['etMonth'] == $month)) {
                                            echo ' selected';
                                        }
                                        echo '>' . htmlspecialchars($month) . '</option>';
                                    }
                                } else {
                                    echo '<option value="">No months available</option>';
                                }
                                ?>
                            </select>
                            <div class="invalid-feedback">Please select a month.</div>
                            <label class="form-label mt-2">Quarter: <span id="quarter_label"><?php echo $trans ? $trans['quarter'] : $et_info['quarter']; ?></span></label>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Employee Name</label>
                            <input type="text" name="employee_name" class="form-control" value="<?php echo $trans ? htmlspecialchars($trans['employee_name']) : ''; ?>" required>
                            <div class="invalid-feedback">Please enter an employee name.</div>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Ordered By</label>
                            <input type="text" name="ordered_by" class="form-control" value="<?php echo $trans ? htmlspecialchars($trans['ordered_by']) : ''; ?>" required>
                            <div class="invalid-feedback">Please enter the ordered by name.</div>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Reason</label>
                            <textarea name="reason" class="form-control"><?php echo $trans ? htmlspecialchars($trans['reason']) : ''; ?></textarea>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Amount</label>
                            <input type="number" step="0.01" name="amount" class="form-control" value="<?php echo $trans ? $trans['amount'] : ''; ?>" required>
                            <div class="invalid-feedback">Please enter a valid amount.</div>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Remaining Monthly: <span id="remaining_month">0.00</span></label>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Remaining Quarterly: <span id="remaining_quarter">0.00</span></label>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Remaining Yearly: <span id="remaining_year">0.00</span></label>
                        </div>
                        <button type="submit" class="btn btn-primary"><?php echo $trans ? 'Update' : 'Save'; ?></button>
                        <button type="button" class="btn btn-info" onclick="window.print()">Print</button>
                    </form>
                    <h3 class="mt-4">Existing Transactions</h3>
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Owner</th>
                                <th>Code</th>
                                <th>Employee</th>
                                <th>Amount</th>
                                <th>Month</th>
                                <th>Quarter</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($transactions as $t): ?>
                                <tr>
                                    <td><?php echo $t['id']; ?></td>
                                    <td><?php echo htmlspecialchars($t['owner_code']); ?></td>
                                    <td><?php echo htmlspecialchars($t['budget_code']); ?></td>
                                    <td><?php echo htmlspecialchars($t['employee_name']); ?></td>
                                    <td><?php echo number_format($t['amount'], 2); ?></td>
                                    <td><?php echo htmlspecialchars($t['et_month']); ?></td>
                                    <td><?php echo $t['quarter']; ?></td>
                                    <td>
                                        <a href="?action=edit&id=<?php echo $t['id']; ?>" class="btn btn-secondary btn-sm">Edit</a>
                                        <a href="?action=delete&id=<?php echo $t['id']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure?')">Delete</a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', () => {
            const sidebar = document.getElementById('sidebar');
            const toggleBtn = document.getElementById('sidebarToggle');
            if (toggleBtn && sidebar) {
                toggleBtn.addEventListener('click', () => {
                    sidebar.classList.toggle('active');
                });
            }
        });

        function loadAvailable() {
            const ownerId = document.querySelector('select[name="owner_id"]').value;
            const codeId = document.querySelector('select[name="code_id"]').value;
            const month = document.querySelector('select[name="et_month"]').value;

            if (ownerId && codeId && month) {
                fetch(`get_remaining.php?owner_id=${ownerId}&code_id=${codeId}&month=${encodeURIComponent(month)}`)
                    .then(response => response.json())
                    .then(data => {
                        document.getElementById('remaining_month').textContent = data.remaining_month.toFixed(2);
                        document.getElementById('remaining_quarter').textContent = data.remaining_quarter.toFixed(2);
                        document.getElementById('remaining_year').textContent = data.remaining_year.toFixed(2);
                    })
                    .catch(error => console.error('Error:', error));
            }
        }

        function updateQuarter() {
            const month = document.getElementById('month').value;
            const quarterMap = {
                'ሐምሌ': 1, 'ነሐሴ': 1, 'መስከረም': 1,
                'ጥቅምት': 2, 'ህዳር': 2, 'ታኅሳስ': 2,
                'ጥር': 3, 'የካቲቷ': 3, 'መጋቢቷ': 3,
                'ሚያዝያ': 4, 'ግንቦቷ': 4, 'ሰኔ': 4
            };
            document.getElementById('quarter_label').textContent = quarterMap[month] || 0;
            loadAvailable();
        }
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>