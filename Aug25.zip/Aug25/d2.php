<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Financial Dashboard | Afar Regional Health Bureau</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        primary: '#6366f1',
                        secondary: '#8b5cf6',
                        dark: '#1f2937',
                        darker: '#111827',
                    }
                }
            }
        }
    </script>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap');
        
        body {
            font-family: 'Inter', sans-serif;
            background: linear-gradient(135deg, #0f172a 0%, #1e293b 100%);
            min-height: 100vh;
        }
        
        .card-hover {
            transition: all 0.3s ease;
        }
        
        .card-hover:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.3);
        }
        
        .gradient-border {
            position: relative;
            background: linear-gradient(135deg, #1f2937 0%, #111827 100%);
            padding: 1px;
            border-radius: 0.75rem;
        }
        
        .gradient-border::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            border-radius: 0.75rem;
            padding: 2px;
            background: linear-gradient(135deg, #6366f1 0%, #8b5cf6 100%);
            -webkit-mask: linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0);
            mask: linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0);
            -webkit-mask-composite: xor;
            mask-composite: exclude;
            pointer-events: none;
        }
        
        .progress-bar {
            background: linear-gradient(90deg, #6366f1 0%, #8b5cf6 100%);
            height: 8px;
            border-radius: 4px;
            transition: width 1s ease-in-out;
        }
        
        .chart-bar {
            transition: all 0.3s ease;
        }
        
        .chart-bar:hover {
            opacity: 0.8;
            transform: scaleY(1.05);
        }
        
        .notification-dot {
            position: absolute;
            top: -5px;
            right: -5px;
            width: 12px;
            height: 12px;
            background: #ef4444;
            border-radius: 50%;
        }
    </style>
</head>
<body class="text-gray-200">
    <div class="min-h-screen py-8 px-4 sm:px-6 lg:px-8">
        <div class="max-w-7xl mx-auto">
            <!-- Header -->
            <div class="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 p-6 gradient-border">
                <div>
                    <h1 class="text-2xl md:text-3xl font-bold">
                        <span class="text-white">Welcome to Afar Regional Health Bureau's Financial System,</span>
                        <span class="text-indigo-300">Admin User</span>!
                    </h1>
                    <p class="text-indigo-200 mt-2">Here's your financial overview for October 2023</p>
                </div>
                <div class="flex items-center space-x-4 mt-4 md:mt-0">
                    <div class="relative">
                        <button class="bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-lg flex items-center transition">
                            <i class="fas fa-bell mr-2"></i> Notifications
                            <span class="notification-dot"></span>
                        </button>
                    </div>
                    <button onclick="window.print()" class="bg-gradient-to-r from-indigo-500 to-purple-600 hover:from-indigo-600 hover:to-purple-700 text-white px-4 py-2 rounded-lg flex items-center transition">
                        <i class="fas fa-print mr-2"></i> Print Report
                    </button>
                </div>
            </div>

            <!-- Stats Grid -->
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
                <div class="bg-gradient-to-br from-gray-800 to-gray-900 rounded-xl p-6 card-hover">
                    <div class="flex justify-between items-start">
                        <div>
                            <p class="text-gray-400">Annual Budget</p>
                            <h3 class="text-2xl font-bold text-white mt-1">$542,890</h3>
                        </div>
                        <div class="bg-indigo-500 p-3 rounded-lg">
                            <i class="fas fa-coins text-white text-xl"></i>
                        </div>
                    </div>
                    <div class="mt-4">
                        <div class="flex justify-between text-sm text-gray-400 mb-1">
                            <span>Spent: $283,560</span>
                            <span>72%</span>
                        </div>
                        <div class="w-full bg-gray-700 rounded-full h-2">
                            <div class="progress-bar rounded-full h-2" style="width: 72%"></div>
                        </div>
                    </div>
                </div>

                <div class="bg-gradient-to-br from-gray-800 to-gray-900 rounded-xl p-6 card-hover">
                    <div class="flex justify-between items-start">
                        <div>
                            <p class="text-gray-400">Expenses YTD</p>
                            <h3 class="text-2xl font-bold text-white mt-1">$283,560</h3>
                        </div>
                        <div class="bg-green-500 p-3 rounded-lg">
                            <i class="fas fa-chart-line text-white text-xl"></i>
                        </div>
                    </div>
                    <div class="mt-4">
                        <p class="text-green-400 flex items-center">
                            <i class="fas fa-arrow-up mr-1"></i> 
                            <span>12.5% from last quarter</span>
                        </p>
                    </div>
                </div>

                <div class="bg-gradient-to-br from-gray-800 to-gray-900 rounded-xl p-6 card-hover">
                    <div class="flex justify-between items-start">
                        <div>
                            <p class="text-gray-400">Pending Requests</p>
                            <h3 class="text-2xl font-bold text-white mt-1">24</h3>
                        </div>
                        <div class="bg-amber-500 p-3 rounded-lg">
                            <i class="fas fa-clock text-white text-xl"></i>
                        </div>
                    </div>
                    <div class="mt-4">
                        <p class="text-amber-400 flex items-center">
                            <i class="fas fa-exclamation-circle mr-1"></i> 
                            <span>8 require immediate attention</span>
                        </p>
                    </div>
                </div>

                <div class="bg-gradient-to-br from-gray-800 to-gray-900 rounded-xl p-6 card-hover">
                    <div class="flex justify-between items-start">
                        <div>
                            <p class="text-gray-400">Savings YTD</p>
                            <h3 class="text-2xl font-bold text-white mt-1">$42,800</h3>
                        </div>
                        <div class="bg-blue-500 p-3 rounded-lg">
                            <i class="fas fa-piggy-bank text-white text-xl"></i>
                        </div>
                    </div>
                    <div class="mt-4">
                        <p class="text-blue-400 flex items-center">
                            <i class="fas fa-arrow-up mr-1"></i> 
                            <span>7.2% from last year</span>
                        </p>
                    </div>
                </div>
            </div>

            <!-- Charts & Transactions -->
            <div class="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
                <!-- Budget Chart -->
                <div class="bg-gradient-to-br from-gray-800 to-gray-900 rounded-xl p-6 card-hover">
                    <h2 class="text-xl font-bold text-white mb-6">Budget Allocation</h2>
                    <div class="flex items-end justify-between h-64 mt-8">
                        <div class="flex flex-col items-center">
                            <div class="chart-bar w-12 bg-gradient-to-t from-indigo-500 to-purple-600 rounded-t-lg" style="height: 160px;"></div>
                            <p class="text-gray-400 mt-2 text-sm">Medical</p>
                        </div>
                        <div class="flex flex-col items-center">
                            <div class="chart-bar w-12 bg-gradient-to-t from-indigo-500 to-purple-600 rounded-t-lg" style="height: 120px;"></div>
                            <p class="text-gray-400 mt-2 text-sm">Operations</p>
                        </div>
                        <div class="flex flex-col items-center">
                            <div class="chart-bar w-12 bg-gradient-to-t from-indigo-500 to-purple-600 rounded-t-lg" style="height: 80px;"></div>
                            <p class="text-gray-400 mt-2 text-sm">HR</p>
                        </div>
                        <div class="flex flex-col items-center">
                            <div class="chart-bar w-12 bg-gradient-to-t from-indigo-500 to-purple-600 rounded-t-lg" style="height: 100px;"></div>
                            <p class="text-gray-400 mt-2 text-sm">Facilities</p>
                        </div>
                        <div class="flex flex-col items-center">
                            <div class="chart-bar w-12 bg-gradient-to-t from-indigo-500 to-purple-600 rounded-t-lg" style="height: 60px;"></div>
                            <p class="text-gray-400 mt-2 text-sm">Training</p>
                        </div>
                        <div class="flex flex-col items-center">
                            <div class="chart-bar w-12 bg-gradient-to-t from-indigo-500 to-purple-600 rounded-t-lg" style="height: 40px;"></div>
                            <p class="text-gray-400 mt-2 text-sm">Research</p>
                        </div>
                    </div>
                </div>

                <!-- Recent Transactions -->
                <div class="bg-gradient-to-br from-gray-800 to-gray-900 rounded-xl p-6 card-hover">
                    <div class="flex justify-between items-center mb-6">
                        <h2 class="text-xl font-bold text-white">Recent Transactions</h2>
                        <button class="text-indigo-400 hover:text-indigo-300 text-sm flex items-center">
                            View all <i class="fas fa-chevron-right ml-1 text-xs"></i>
                        </button>
                    </div>
                    
                    <div class="space-y-4">
                        <div class="flex justify-between items-center p-3 hover:bg-gray-800 rounded-lg transition">
                            <div class="flex items-center">
                                <div class="bg-indigo-500/20 p-2 rounded-lg">
                                    <i class="fas fa-pills text-indigo-400"></i>
                                </div>
                                <div class="ml-4">
                                    <p class="font-medium text-white">Pharmaceutical Supplies</p>
                                    <p class="text-sm text-gray-400">Oct 12, 2023</p>
                                </div>
                            </div>
                            <div class="text-right">
                                <p class="font-medium text-white">$28,500</p>
                                <p class="text-sm text-red-400">Expense</p>
                            </div>
                        </div>
                        
                        <div class="flex justify-between items-center p-3 hover:bg-gray-800 rounded-lg transition">
                            <div class="flex items-center">
                                <div class="bg-amber-500/20 p-2 rounded-lg">
                                    <i class="fas fa-laptop-medical text-amber-400"></i>
                                </div>
                                <div class="ml-4">
                                    <p class="font-medium text-white">Medical Equipment</p>
                                    <p class="text-sm text-gray-400">Oct 15, 2023</p>
                                </div>
                            </div>
                            <div class="text-right">
                                <p class="font-medium text-white">$42,800</p>
                                <p class="text-sm text-red-400">Expense</p>
                            </div>
                        </div>
                        
                        <div class="flex justify-between items-center p-3 hover:bg-gray-800 rounded-lg transition">
                            <div class="flex items-center">
                                <div class="bg-blue-500/20 p-2 rounded-lg">
                                    <i class="fas fa-chalkboard-teacher text-blue-400"></i>
                                </div>
                                <div class="ml-4">
                                    <p class="font-medium text-white">Training Program</p>
                                    <p class="text-sm text-gray-400">Oct 8, 2023</p>
                                </div>
                            </div>
                            <div class="text-right">
                                <p class="font-medium text-white">$12,300</p>
                                <p class="text-sm text-red-400">Expense</p>
                            </div>
                        </div>
                        
                        <div class="flex justify-between items-center p-3 hover:bg-gray-800 rounded-lg transition">
                            <div class="flex items-center">
                                <div class="bg-green-500/20 p-2 rounded-lg">
                                    <i class="fas fa-hand-holding-usd text-green-400"></i>
                                </div>
                                <div class="ml-4">
                                    <p class="font-medium text-white">Government Grant</p>
                                    <p class="text-sm text-gray-400">Oct 5, 2023</p>
                                </div>
                            </div>
                            <div class="text-right">
                                <p class="font-medium text-white">$75,000</p>
                                <p class="text-sm text-green-400">Income</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Additional Panels -->
            <div class="grid grid-cols-1 lg:grid-cols-2 gap-8">
                <!-- Quick Actions -->
                <div class="bg-gradient-to-br from-gray-800 to-gray-900 rounded-xl p-6 card-hover">
                    <h2 class="text-xl font-bold text-white mb-6">Quick Actions</h2>
                    <div class="grid grid-cols-2 gap-4">
                        <button class="bg-indigo-500/20 hover:bg-indigo-500/30 text-indigo-400 p-4 rounded-lg flex flex-col items-center justify-center transition">
                            <i class="fas fa-plus-circle text-2xl mb-2"></i>
                            <span>New Request</span>
                        </button>
                        <button class="bg-purple-500/20 hover:bg-purple-500/30 text-purple-400 p-4 rounded-lg flex flex-col items-center justify-center transition">
                            <i class="fas fa-file-invoice-dollar text-2xl mb-2"></i>
                            <span>Generate Report</span>
                        </button>
                        <button class="bg-blue-500/20 hover:bg-blue-500/30 text-blue-400 p-4 rounded-lg flex flex-col items-center justify-center transition">
                            <i class="fas fa-exchange-alt text-2xl mb-2"></i>
                            <span>Transfer Funds</span>
                        </button>
                        <button class="bg-green-500/20 hover:bg-green-500/30 text-green-400 p-4 rounded-lg flex flex-col items-center justify-center transition">
                            <i class="fas fa-download text-2xl mb-2"></i>
                            <span>Export Data</span>
                        </button>
                    </div>
                </div>

                <!-- Upcoming Deadlines -->
                <div class="bg-gradient-to-br from-gray-800 to-gray-900 rounded-xl p-6 card-hover">
                    <div class="flex justify-between items-center mb-6">
                        <h2 class="text-xl font-bold text-white">Upcoming Deadlines</h2>
                        <button class="text-indigo-400 hover:text-indigo-300 text-sm flex items-center">
                            View all <i class="fas fa-chevron-right ml-1 text-xs"></i>
                        </button>
                    </div>
                    
                    <div class="space-y-4">
                        <div class="flex justify-between items-center">
                            <div class="flex items-center">
                                <div class="bg-rose-500/20 p-2 rounded-lg">
                                    <i class="fas fa-exclamation-triangle text-rose-400"></i>
                                </div>
                                <div class="ml-4">
                                    <p class="font-medium text-white">Q3 Financial Report</p>
                                    <p class="text-sm text-gray-400">Due in 3 days</p>
                                </div>
                            </div>
                            <span class="bg-rose-500/20 text-rose-400 text-xs font-medium px-2.5 py-0.5 rounded-full">Urgent</span>
                        </div>
                        
                        <div class="flex justify-between items-center">
                            <div class="flex items-center">
                                <div class="bg-amber-500/20 p-2 rounded-lg">
                                    <i class="fas fa-file-alt text-amber-400"></i>
                                </div>
                                <div class="ml-4">
                                    <p class="font-medium text-white">Budget Proposal</p>
                                    <p class="text-sm text-gray-400">Due in 1 week</p>
                                </div>
                            </div>
                            <span class="bg-amber-500/20 text-amber-400 text-xs font-medium px-2.5 py-0.5 rounded-full">Pending</span>
                        </div>
                        
                        <div class="flex justify-between items-center">
                            <div class="flex items-center">
                                <div class="bg-blue-500/20 p-2 rounded-lg">
                                    <i class="fas fa-money-check-alt text-blue-400"></i>
                                </div>
                                <div class="ml-4">
                                    <p class="font-medium text-white">Vendor Payments</p>
                                    <p class="text-sm text-gray-400">Due in 10 days</p>
                                </div>
                            </div>
                            <span class="bg-blue-500/20 text-blue-400 text-xs font-medium px-2.5 py-0.5 rounded-full">Upcoming</span>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Footer -->
            <div class="mt-10 text-center text-gray-500 text-sm">
                <p>© 2023 Afar Regional Health Bureau Financial System. All rights reserved.</p>
            </div>
        </div>
    </div>

    <script>
        // Simple animation for progress bars
        document.addEventListener('DOMContentLoaded', function() {
            const progressBars = document.querySelectorAll('.progress-bar');
            progressBars.forEach(bar => {
                const width = bar.style.width;
                bar.style.width = '0';
                setTimeout(() => {
                    bar.style.width = width;
                }, 500);
            });
        });
    </script>
</body>
</html>