<?php
session_start();
include 'includes/db.php';
if (!isset($_SESSION['user_id'])) {
    header('Location: index.php');
    exit;
}

// Fetch data for charts: Allocated and Used per directorate
$directorate_data = [];
$stmt = $pdo->query("SELECT o.id, o.name, SUM(b.yearly_amount) AS allocated, (SELECT SUM(t.amount) FROM transactions t WHERE t.owner_id = o.id) AS used 
                     FROM budget_owners o LEFT JOIN budgets b ON o.id = b.owner_id GROUP BY o.id");
while ($row = $stmt->fetch()) {
    $directorate_data[] = $row;
}

// Fetch recent transactions
$recent_transactions = $pdo->query("SELECT t.*, o.code AS owner_code, c.code AS budget_code 
                                    FROM transactions t 
                                    JOIN budget_owners o ON t.owner_id = o.id 
                                    JOIN budget_codes c ON t.code_id = c.id 
                                    ORDER BY t.date DESC LIMIT 5")->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="robots" content="noindex, nofollow">
    <title>Dashboard - Budget System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap" rel="stylesheet">
    <link href="css/styles.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body class="dashboard-body">
    <!-- Sidebar -->
    <div class="sidebar" id="sidebar">
        <div class="sidebar-header">
            <i class="fas fa-wallet fa-2x"></i>
            <h3>Budget System</h3>
        </div>
        <ul class="nav flex-column">
            <li class="nav-item">
                <a class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'dashboard.php' ? 'active' : ''; ?>" href="dashboard.php">
                    <i class="fas fa-tachometer-alt"></i> Dashboard
                </a>
            </li>
            <?php if ($_SESSION['role'] == 'admin'): ?>
                <li class="nav-item">
                    <a class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'budget_adding.php' ? 'active' : ''; ?>" href="budget_adding.php">
                        <i class="fas fa-plus-circle"></i> Budget Adding
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'settings_owners.php' ? 'active' : ''; ?>" href="settings_owners.php">
                        <i class="fas fa-building"></i> Settings Owners
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'settings_codes.php' ? 'active' : ''; ?>" href="settings_codes.php">
                        <i class="fas fa-code"></i> Settings Codes
                    </a>
                </li>
            <?php endif; ?>
            <li class="nav-item">
                <a class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'transaction.php' ? 'active' : ''; ?>" href="transaction.php">
                    <i class="fas fa-exchange-alt"></i> Transaction
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'fuel_management.php' ? 'active' : ''; ?>" href="fuel_management.php">
                    <i class="fas fa-gas-pump"></i> Fuel Management
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'users_management.php' ? 'active' : ''; ?>" href="users_management.php">
                    <i class="fas fa-users"></i> Users Management
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="logout.php">
                    <i class="fas fa-sign-out-alt"></i> Logout
                </a>
            </li>
        </ul>
        <!-- Debug: Check if sidebar is loaded -->
        <script>console.log('Sidebar loaded');</script>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <button class="btn btn-primary sidebar-toggle d-md-none" id="sidebarToggle">
            <i class="fas fa-bars"></i>
        </button>
        <div class="container-fluid">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h1 class="dashboard-title">Welcome, <?php echo htmlspecialchars($_SESSION['username']); ?>!</h1>
                <button onclick="window.print()" class="btn btn-info"><i class="fas fa-print"></i> Print Report</button>
            </div>

            <!-- Budget Overview Cards -->
            <div class="row g-4">
                <div class="col-md-4">
                    <div class="card dashboard-card">
                        <div class="card-body">
                            <h5 class="card-title"><i class="fas fa-money-bill-wave"></i> Total Allocated</h5>
                            <p class="card-text"><?php echo number_format(array_sum(array_column($directorate_data, 'allocated')), 2); ?> ETB</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card dashboard-card">
                        <div class="card-body">
                            <h5 class="card-title"><i class="fas fa-chart-line"></i> Total Used</h5>
                            <p class="card-text"><?php echo number_format(array_sum(array_column($directorate_data, 'used')), 2); ?> ETB</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card dashboard-card">
                        <div class="card-body">
                            <h5 class="card-title"><i class="fas fa-wallet"></i> Remaining Budget</h5>
                            <p class="card-text"><?php echo number_format(array_sum(array_column($directorate_data, 'allocated')) - array_sum(array_column($directorate_data, 'used')), 2); ?> ETB</p>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Charts -->
            <div class="row g-4 mt-4">
                <div class="col-md-6">
                    <div class="card dashboard-card">
                        <div class="card-body">
                            <h5 class="card-title">Budget Usage Proportion (%)</h5>
                            <canvas id="pieChart"></canvas>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="card dashboard-card">
                        <div class="card-body">
                            <h5 class="card-title">Allocated vs Used Budget</h5>
                            <canvas id="barChart"></canvas>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Recent Transactions -->
            <div class="card dashboard-card mt-4">
                <div class="card-body">
                    <h5 class="card-title">Recent Transactions</h5>
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Owner</th>
                                <th>Code</th>
                                <th>Employee</th>
                                <th>Amount</th>
                                <th>Month</th>
                                <th>Quarter</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($recent_transactions as $t): ?>
                                <tr>
                                    <td><?php echo $t['id']; ?></td>
                                    <td><?php echo htmlspecialchars($t['owner_code']); ?></td>
                                    <td><?php echo htmlspecialchars($t['budget_code']); ?></td>
                                    <td><?php echo htmlspecialchars($t['employee_name']); ?></td>
                                    <td><?php echo number_format($t['amount'], 2); ?></td>
                                    <td><?php echo htmlspecialchars($t['et_month']); ?></td>
                                    <td><?php echo $t['quarter']; ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <script>
        const directorateData = <?php echo json_encode($directorate_data); ?>;

        // Pie Chart: Usage Proportion
        const pieCtx = document.getElementById('pieChart').getContext('2d');
        const pieChart = new Chart(pieCtx, {
            type: 'pie',
            data: {
                labels: directorateData.map(d => d.name),
                datasets: [{
                    label: 'Used Budget Proportion',
                    data: directorateData.map(d => ((d.used / d.allocated) * 100 || 0).toFixed(2)),
                    backgroundColor: ['#FF6384', '#36A2EB', '#FFCE56', '#4BC0C0', '#9966FF'],
                    borderColor: '#fff',
                    borderWidth: 2
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: { position: 'top', labels: { font: { family: 'Roboto', size: 14 } } },
                    title: { display: true, text: 'Budget Usage Proportion (%)', font: { family: 'Roboto', size: 16 } }
                },
                animation: { animateScale: true, animateRotate: true }
            }
        });

        // Bar Chart: Allocated vs Used
        const barCtx = document.getElementById('barChart').getContext('2d');
        const barChart = new Chart(barCtx, {
            type: 'bar',
            data: {
                labels: directorateData.map(d => d.name),
                datasets: [
                    { label: 'Allocated', data: directorate_data.map(d => d.allocated || 0), backgroundColor: '#36A2EB', borderRadius: 5 },
                    { label: 'Used', data: directorate_data.map(d => d.used || 0), backgroundColor: '#FF6384', borderRadius: 5 }
                ]
            },
            options: {
                responsive: true,
                scales: {
                    y: { beginAtZero: true, title: { display: true, text: 'Amount (ETB)' } },
                    x: { title: { display: true, text: 'Directorates' } }
                },
                plugins: {
                    legend: { position: 'top', labels: { font: { family: 'Roboto', size: 14 } } },
                    title: { display: true, text: 'Allocated vs Used Budget', font: { family: 'Roboto', size: 16 } }
                }
            }
        });

        // Sidebar Toggle
        document.addEventListener('DOMContentLoaded', () => {
            const sidebar = document.getElementById('sidebar');
            const toggleBtn = document.getElementById('sidebarToggle');
            if (toggleBtn && sidebar) {
                toggleBtn.addEventListener('click', () => {
                    sidebar.classList.toggle('active');
                    console.log('Sidebar toggled');
                });
            } else {
                console.error('Sidebar or toggle button not found');
            }
        });
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>