<?php
include 'includes/db.php';
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header('Location: dashboard.php');
    exit;
}

$owners = $pdo->query("SELECT * FROM budget_owners")->fetchAll();
$owner = null;
if (isset($_GET['action']) && $_GET['action'] == 'edit' && isset($_GET['id'])) {
    $stmt = $pdo->prepare("SELECT * FROM budget_owners WHERE id = ?");
    $stmt->execute([$_GET['id']]);
    $owner = $stmt->fetch();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $code = $_POST['code'];
    $name = $_POST['name'];
    if (isset($_POST['id']) && $_POST['action'] == 'update') {
        $stmt = $pdo->prepare("UPDATE budget_owners SET code = ?, name = ? WHERE id = ?");
        $stmt->execute([$code, $name, $_POST['id']]);
        $message = 'Owner updated';
    } else {
        $stmt = $pdo->prepare("INSERT INTO budget_owners (code, name) VALUES (?, ?)");
        $stmt->execute([$code, $name]);
        $message = 'Owner added';
    }
}

if (isset($_GET['action']) && $_GET['action'] == 'delete' && isset($_GET['id'])) {
    $stmt = $pdo->prepare("DELETE FROM budget_owners WHERE id = ?");
    $stmt->execute([$_GET['id']]);
    $message = 'Owner deleted';
    header('Location: settings_owners.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Settings - Owners - Budget System</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <!-- Same navbar as dashboard.php -->
    </nav>
    <div class="container">
        <div class="card mt-4">
            <div class="card-body">
                <h2 class="card-title">Settings - Budget Owners</h2>
                <?php if (isset($message)): ?>
                    <div class="alert alert-info"><?php echo $message; ?></div>
                <?php endif; ?>
                <form method="post">
                    <?php if ($owner): ?>
                        <input type="hidden" name="id" value="<?php echo $owner['id']; ?>">
                        <input type="hidden" name="action" value="update">
                    <?php endif; ?>
                    <div class="mb-3">
                        <label class="form-label">Code</label>
                        <input type="text" name="code" class="form-control" value="<?php echo $owner ? $owner['code'] : ''; ?>" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Name</label>
                        <input type="text" name="name" class="form-control" value="<?php echo $owner ? $owner['name'] : ''; ?>" required>
                    </div>
                    <button type="submit" class="btn btn-primary"><?php echo $owner ? 'Update' : 'Add'; ?> Owner</button>
                    <button type="button" class="btn btn-info" onclick="window.print()">Print</button>
                </form>
                <h3 class="mt-4">Existing Owners</h3>
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>Code</th>
                            <th>Name</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($owners as $o): ?>
                            <tr>
                                <td><?php echo $o['code']; ?></td>
                                <td><?php echo $o['name']; ?></td>
                                <td>
                                    <a href="?action=edit&id=<?php echo $o['id']; ?>" class="btn btn-secondary btn-sm">Edit</a>
                                    <a href="?action=delete&id=<?php echo $o['id']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure?')">Delete</a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>