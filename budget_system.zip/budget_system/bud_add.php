<?php
session_start();
include 'includes/db.php';
include 'includes/functions.php';
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header('Location: dashboard.php');
    exit;
}

$owners = $pdo->query("SELECT * FROM budget_owners")->fetchAll();
$codes = $pdo->query("SELECT * FROM budget_codes")->fetchAll();

// Fetch budgets based on selected owner and code (filtered via POST or default to all)
$selected_owner_id = isset($_POST['owner_id']) ? $_POST['owner_id'] : (isset($_GET['owner_id']) ? $_GET['owner_id'] : null);
$selected_code_id = isset($_POST['code_id']) ? $_POST['code_id'] : (isset($_GET['code_id']) ? $_GET['code_id'] : null);
$budget_query = "SELECT b.*, o.code AS owner_code, o.name AS owner_name, c.code AS budget_code, c.name AS budget_name 
                 FROM budgets b 
                 JOIN budget_owners o ON b.owner_id = o.id 
                 JOIN budget_codes c ON b.code_id = c.id";
$params = [];
if ($selected_owner_id && $selected_code_id) {
    $budget_query .= " WHERE b.owner_id = ? AND b.code_id = ?";
    $params = [$selected_owner_id, $selected_code_id];
}
$budgets = $pdo->prepare($budget_query);
$budgets->execute($params);
$budgets = $budgets->fetchAll();

$budget = null;
if (isset($_GET['action']) && $_GET['action'] == 'edit' && isset($_GET['id'])) {
    $stmt = $pdo->prepare("SELECT * FROM budgets WHERE id = ?");
    $stmt->execute([$_GET['id']]);
    $budget = $stmt->fetch();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && !isset($_POST['ajax'])) {
    $owner_id = $_POST['owner_id'];
    $code_id = $_POST['code_id'];
    $adding_date = $_POST['adding_date'];
    $et_info = getEtMonthAndQuarter($adding_date);
    $month = $_POST['month'];
    $quarter = $quarterMap[$month] ?? 0;
    $yearly_amount = (float)($_POST['yearly_amount'] ?? 0);
    $monthly_amount = (float)($_POST['monthly_amount'] ?? 0);
    $year = date('Y', strtotime($adding_date)) - 8;

    $pdo->beginTransaction();
    try {
        if (isset($_POST['id']) && $_POST['action'] == 'update') {
            // Update existing budget
            $stmt = $pdo->prepare("UPDATE budgets SET owner_id = ?, code_id = ?, adding_date = ?, year = ?, yearly_amount = ?, month = ?, monthly_amount = ?, quarter = ?, remaining_yearly = ?, remaining_monthly = ?, remaining_quarterly = ? WHERE id = ?");
            $stmt->execute([$owner_id, $code_id, $adding_date, $year, $yearly_amount, $month, $monthly_amount, $quarter, $yearly_amount, $monthly_amount, $monthly_amount * 3, $_POST['id']]);
            $message = 'Budget updated';
        } else {
            // Check if yearly budget already exists for this owner, code, and year
            $stmt = $pdo->prepare("SELECT id FROM budgets WHERE owner_id = ? AND code_id = ? AND year = ? AND monthly_amount = 0");
            $stmt->execute([$owner_id, $code_id, $year]);
            $existing_yearly = $stmt->fetch();

            if ($yearly_amount > 0 && !$existing_yearly) {
                // Add yearly budget once
                $stmt = $pdo->prepare("INSERT INTO budgets (owner_id, code_id, adding_date, year, yearly_amount, month, monthly_amount, quarter, remaining_yearly, remaining_monthly, remaining_quarterly) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
                $stmt->execute([$owner_id, $code_id, $adding_date, $year, $yearly_amount, '', 0, 0, $yearly_amount, 0, 0]);
                $message = 'Yearly budget added';
            } elseif ($monthly_amount > 0) {
                // Add monthly distribution (requires yearly budget to exist)
                $stmt = $pdo->prepare("SELECT id, yearly_amount, remaining_yearly FROM budgets WHERE owner_id = ? AND code_id = ? AND year = ? AND monthly_amount = 0");
                $stmt->execute([$owner_id, $code_id, $year]);
                $yearly_budget = $stmt->fetch();
                if ($yearly_budget && $yearly_budget['remaining_yearly'] >= $monthly_amount) {
                    $new_remaining_yearly = $yearly_budget['remaining_yearly'] - $monthly_amount;
                    $stmt = $pdo->prepare("INSERT INTO budgets (owner_id, code_id, adding_date, year, yearly_amount, month, monthly_amount, quarter, remaining_yearly, remaining_monthly, remaining_quarterly) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
                    $stmt->execute([$owner_id, $code_id, $adding_date, $year, 0, $month, $monthly_amount, $quarter, $new_remaining_yearly, $monthly_amount, $monthly_amount * 3]);
                    $stmt = $pdo->prepare("UPDATE budgets SET remaining_yearly = ? WHERE id = ?");
                    $stmt->execute([$new_remaining_yearly, $yearly_budget['id']]);
                    $message = 'Monthly budget added';
                } else {
                    $message = 'Insufficient yearly budget or no yearly budget exists';
                }
            } else {
                $message = 'Please enter a yearly or monthly amount';
            }
        }
        $pdo->commit();
    } catch (Exception $e) {
        $pdo->rollBack();
        $message = 'Error: ' . $e->getMessage();
    }
}

if (isset($_GET['action']) && $_GET['action'] == 'delete' && isset($_GET['id'])) {
    $stmt = $pdo->prepare("SELECT owner_id, code_id, year, monthly_amount, remaining_yearly, remaining_monthly FROM budgets WHERE id = ?");
    $stmt->execute([$_GET['id']]);
    $budget = $stmt->fetch();

    $pdo->beginTransaction();
    try {
        if ($budget['monthly_amount'] > 0) {
            $stmt = $pdo->prepare("UPDATE budgets SET remaining_yearly = remaining_yearly + ? WHERE owner_id = ? AND code_id = ? AND year = ? AND monthly_amount = 0");
            $stmt->execute([$budget['monthly_amount'], $budget['owner_id'], $budget['code_id'], $budget['year']]);
        }
        $stmt = $pdo->prepare("DELETE FROM budgets WHERE id = ?");
        $stmt->execute([$_GET['id']]);
        $pdo->commit();
        $message = 'Budget deleted';
        header('Location: budget_adding.php?owner_id=' . $budget['owner_id'] . '&code_id=' . $budget['code_id']);
        exit;
    } catch (Exception $e) {
        $pdo->rollBack();
        $message = 'Error deleting budget: ' . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="robots" content="noindex, nofollow">
    <title>Budget Adding - Budget System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap" rel="stylesheet">
    <link href="css/styles.css" rel="stylesheet">
</head>
<body class="dashboard-body">
    <!-- Sidebar -->
    <div class="sidebar" id="sidebar">
        <div class="sidebar-header">
            <i class="fas fa-wallet fa-2x"></i>
            <h3>Budget System</h3>
        </div>
        <ul class="nav flex-column">
            <li class="nav-item">
                <a class="nav-link" href="dashboard.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a>
            </li>
            <?php if ($_SESSION['role'] == 'admin'): ?>
                <li class="nav-item">
                    <a class="nav-link active" href="budget_adding.php"><i class="fas fa-plus-circle"></i> Budget Adding</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="settings_owners.php"><i class="fas fa-building"></i> Settings Owners</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="settings_codes.php"><i class="fas fa-code"></i> Settings Codes</a>
                </li>
            <?php endif; ?>
            <li class="nav-item">
                <a class="nav-link" href="transaction.php"><i class="fas fa-exchange-alt"></i> Transaction</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="fuel_management.php"><i class="fas fa-gas-pump"></i> Fuel Management</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="users_management.php"><i class="fas fa-users"></i> Users Management</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
            </li>
        </ul>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <button class="btn btn-primary sidebar-toggle d-md-none" id="sidebarToggle">
            <i class="fas fa-bars"></i>
        </button>
        <div class="container-fluid">
            <div class="card dashboard-card mt-4">
                <div class="card-body">
                    <h2 class="card-title">Budget Adding Form</h2>
                    <?php if (isset($message)): ?>
                        <div class="alert alert-info alert-dismissible fade show" role="alert">
                            <?php echo htmlspecialchars($message); ?>
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>
                    <?php endif; ?>
                    <form method="post" id="budgetForm" class="needs-validation" novalidate>
                        <?php if ($budget): ?>
                            <input type="hidden" name="id" value="<?php echo $budget['id']; ?>">
                            <input type="hidden" name="action" value="update">
                        <?php endif; ?>
                        <div class="mb-3">
                            <label class="form-label">Budget Adding Date</label>
                            <input type="date" id="adding_date" name="adding_date" class="form-control" value="<?php echo $budget ? $budget['adding_date'] : date('Y-m-d'); ?>" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Budget Owners Code</label>
                            <select name="owner_id" id="owner_id" class="form-control" required onchange="filterBudgets()">
                                <?php foreach ($owners as $o): ?>
                                    <option value="<?php echo $o['id']; ?>" <?php echo ($budget && $budget['owner_id'] == $o['id']) || $selected_owner_id == $o['id'] ? 'selected' : ''; ?>>
                                        <?php echo htmlspecialchars($o['code'] . ' - ' . $o['name']); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Budget Code</label>
                            <select name="code_id" id="code_id" class="form-control" required onchange="filterBudgets()">
                                <?php foreach ($codes as $c): ?>
                                    <option value="<?php echo $c['id']; ?>" <?php echo ($budget && $budget['code_id'] == $c['id']) || $selected_code_id == $c['id'] ? 'selected' : ''; ?>>
                                        <?php echo htmlspecialchars($c['code'] . ' - ' . $c['name']); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Select Month Info</label>
                            <select id="month" name="month" class="form-control" required>
                                <option value="">Select Month</option>
                                <?php foreach ($etMonths as $m): ?>
                                    <option value="<?php echo $m; ?>" <?php echo $budget && $budget['month'] == $m ? 'selected' : ''; ?>><?php echo htmlspecialchars($m); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Yearly Amount</label>
                            <input type="number" step="0.01" name="yearly_amount" id="yearly_amount" class="form-control" value="<?php echo $budget && $budget['monthly_amount'] == 0 ? $budget['yearly_amount'] : ''; ?>" onchange="distributeMonthly()">
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Monthly Amount</label>
                            <input type="number" step="0.01" name="monthly_amount" id="monthly_amount" class="form-control" value="<?php echo $budget && $budget['monthly_amount'] > 0 ? $budget['monthly_amount'] : ''; ?>" readonly>
                        </div>
                        <button type="submit" class="btn btn-primary">Save</button>
                        <button type="button" class="btn btn-info" onclick="window.print()">Print</button>
                    </form>
                    <h3 class="mt-4">Existing Budgets</h3>
                    <table class="table table-striped" id="budgetsTable">
                        <thead>
                            <tr>
                                <th data-sort="id">ID <i class="fas fa-sort"></i></th>
                                <th data-sort="owner_name">Owner <i class="fas fa-sort"></i></th>
                                <th data-sort="budget_name">Code <i class="fas fa-sort"></i></th>
                                <th data-sort="month">Month <i class="fas fa-sort"></i></th>
                                <th data-sort="monthly_amount">Monthly Amount <i class="fas fa-sort"></i></th>
                                <th data-sort="yearly_amount">Yearly Amount <i class="fas fa-sort"></i></th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody id="budgetsList">
                            <?php foreach ($budgets as $b): ?>
                                <tr>
                                    <td><?php echo $b['id']; ?></td>
                                    <td><?php echo htmlspecialchars($b['owner_code'] . ' - ' . $b['owner_name']); ?></td>
                                    <td><?php echo htmlspecialchars($b['budget_code'] . ' - ' . $b['budget_name']); ?></td>
                                    <td><?php echo htmlspecialchars($b['month'] ?: 'N/A'); ?></td>
                                    <td><?php echo number_format($b['monthly_amount'], 2); ?></td>
                                    <td><?php echo number_format($b['yearly_amount'], 2); ?></td>
                                    <td>
                                        <a href="?action=edit&id=<?php echo $b['id']; ?>&owner_id=<?php echo $b['owner_id']; ?>&code_id=<?php echo $b['code_id']; ?>" class="btn btn-secondary btn-sm">Edit</a>
                                        <a href="?action=delete&id=<?php echo $b['id']; ?>&owner_id=<?php echo $b['owner_id']; ?>&code_id=<?php echo $b['code_id']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure?')">Delete</a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', () => {
            const sidebar = document.getElementById('sidebar');
            const toggleBtn = document.getElementById('sidebarToggle');
            if (toggleBtn && sidebar) {
                toggleBtn.addEventListener('click', () => {
                    sidebar.classList.toggle('active');
                });
            }

            // Filter budgets on dropdown change
            function filterBudgets() {
                const ownerId = document.getElementById('owner_id').value;
                const codeId = document.getElementById('code_id').value;
                fetch(`budget_adding.php?owner_id=${ownerId}&code_id=${codeId}`)
                    .then(response => response.text())
                    .then(html => {
                        const parser = new DOMParser();
                        const doc = parser.parseFromString(html, 'text/html');
                        const newList = doc.getElementById('budgetsList').innerHTML;
                        document.getElementById('budgetsList').innerHTML = newList;
                    });
            }

            // Distribute yearly amount to monthly (example distribution)
            function distributeMonthly() {
                const yearlyAmount = parseFloat(document.getElementById('yearly_amount').value) || 0;
                if (yearlyAmount > 0) {
                    const months = ['መስከረም', 'ጥቅምት', 'ህዳር', 'ታህሳስ', 'ጥር', 'የካቲት', 'መጋቢት', 'ሚያዝያ', 'ግንቦት', 'ሰኔ', 'ሐምሌ', 'ነሐሴ'];
                    let total = 0;
                    const distribution = [15000, 15000, 15000, 15000, 7500, 7500, 7500, 7500, 15000, 15000, 15000, 15000];
                    let monthlyAmount = 0;
                    for (let i = 0; i < 12; i++) {
                        if (total + distribution[i] <= yearlyAmount) {
                            total += distribution[i];
                            if (i === 4 || i === 5 || i === 6 || i === 7) {
                                monthlyAmount = 7500;
                            } else {
                                monthlyAmount = 15000;
                            }
                        } else {
                            monthlyAmount = (yearlyAmount - total) / (12 - i);
                            break;
                        }
                    }
                    document.getElementById('monthly_amount').value = monthlyAmount.toFixed(2);
                } else {
                    document.getElementById('monthly_amount').value = '';
                }
            }

            // Table sorting
            let sortDirection = 1;
            document.querySelectorAll('#budgetsTable th[data-sort]').forEach(header => {
                header.addEventListener('click', () => {
                    const key = header.getAttribute('data-sort');
                    const tbody = document.getElementById('budgetsList');
                    const rows = Array.from(tbody.getElementsByTagName('tr'));

                    rows.sort((a, b) => {
                        const aValue = a.cells[header.cellIndex].textContent.trim();
                        const bValue = b.cells[header.cellIndex].textContent.trim();
                        return aValue.localeCompare(bValue, 'en', { numeric: true }) * sortDirection;
                    });

                    rows.forEach(row => tbody.appendChild(row));
                    sortDirection *= -1;
                    header.querySelector('i').classList.toggle('fa-sort-up', sortDirection === 1);
                    header.querySelector('i').classList.toggle('fa-sort-down', sortDirection === -1);
                });
            });

            // AJAX form submission
            document.getElementById('budgetForm').addEventListener('submit', function(e) {
                e.preventDefault();
                const formData = new FormData(this);

                fetch('budget_adding.php', {
                    method: 'POST',
                    body: formData
                })
                .then(response => response.json())
                .then(data => {
                    if (data.message) {
                        const alertDiv = document.createElement('div');
                        alertDiv.className = 'alert alert-info alert-dismissible fade show';
                        alertDiv.role = 'alert';
                        alertDiv.innerHTML = `${data.message}<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>`;
                        document.querySelector('.card-body').insertBefore(alertDiv, document.querySelector('form'));
                        filterBudgets(); // Refresh list
                    }
                })
                .catch(error => console.error('Error:', error));
            });
        });
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>