<?php
echo password_hash('admin', PASSWORD_BCRYPT) . "\n";
echo password_hash('officer', PASSWORD_BCRYPT) . "\n";
?>