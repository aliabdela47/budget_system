<?php
include 'includes/db.php';
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header('Location: dashboard.php');
    exit;
}

$codes = $pdo->query("SELECT * FROM budget_codes")->fetchAll();
$code = null;
if (isset($_GET['action']) && $_GET['action'] == 'edit' && isset($_GET['id'])) {
    $stmt = $pdo->prepare("SELECT * FROM budget_codes WHERE id = ?");
    $stmt->execute([$_GET['id']]);
    $code = $stmt->fetch();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $code_val = $_POST['code'];
    $name = $_POST['name'];
    if (isset($_POST['id']) && $_POST['action'] == 'update') {
        $stmt = $pdo->prepare("UPDATE budget_codes SET code = ?, name = ? WHERE id = ?");
        $stmt->execute([$code_val, $name, $_POST['id']]);
        $message = 'Code updated';
    } else {
        $stmt = $pdo->prepare("INSERT INTO budget_codes (code, name) VALUES (?, ?)");
        $stmt->execute([$code_val, $name]);
        $message = 'Code added';
    }
}

if (isset($_GET['action']) && $_GET['action'] == 'delete' && isset($_GET['id'])) {
    $stmt = $pdo->prepare("DELETE FROM budget_codes WHERE id = ?");
    $stmt->execute([$_GET['id']]);
    $message = 'Code deleted';
    header('Location: settings_codes.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Settings - Budget Codes - Budget System</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <!-- Same navbar as dashboard.php -->
    </nav>
    <div class="container">
        <div class="card mt-4">
            <div class="card-body">
                <h2 class="card-title">Settings - Budget Codes</h2>
                <?php if (isset($message)): ?>
                    <div class="alert alert-info"><?php echo $message; ?></div>
                <?php endif; ?>
                <form method="post">
                    <?php if ($code): ?>
                        <input type="hidden" name="id" value="<?php echo $code['id']; ?>">
                        <input type="hidden" name="action" value="update">
                    <?php endif; ?>
                    <div class="mb-3">
                        <label class="form-label">Code</label>
                        <input type="text" name="code" class="form-control" value="<?php echo $code ? $code['code'] : ''; ?>" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Name</label>
                        <input type="text" name="name" class="form-control" value="<?php echo $code ? $code['name'] : ''; ?>" required>
                    </div>
                    <button type="submit" class="btn btn-primary"><?php echo $code ? 'Update' : 'Add'; ?> Code</button>
                    <button type="button" class="btn btn-info" onclick="window.print()">Print</button>
                </form>
                <h3 class="mt-4">Existing Codes</h3>
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>Code</th>
                            <th>Name</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($codes as $c): ?>
                            <tr>
                                <td><?php echo $c['code']; ?></td>
                                <td><?php echo $c['name']; ?></td>
                                <td>
                                    <a href="?action=edit&id=<?php echo $c['id']; ?>" class="btn btn-secondary btn-sm">Edit</a>
                                    <a href="?action=delete&id=<?php echo $c['id']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure?')">Delete</a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>