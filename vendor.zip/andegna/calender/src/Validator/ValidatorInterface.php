<?php

namespace Andegna\Validator;

/**
 * Interface Validator.
 */
interface ValidatorInterface
{
    public function isValid();
}
